#ifndef VERSION_H
#define VERSION_H

extern const char VERSION[];

#endif /* VERSION_H */
